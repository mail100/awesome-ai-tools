import { i, id, init, InstaQLEntity } from "@instantdb/react-native";
import { useEffect, useState } from "react";
import {
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

// ============================================================================
// INSTANT SETUP - Initialize connection and define schema
// ============================================================================

// Define schema with posts, comments, and votes
const schema = i.schema({
  entities: {
    posts: i.entity({
      title: i.string(),
      body: i.string(),
      authorId: i.string(),
      timestamp: i.number().indexed(),
    }),
    comments: i.entity({
      text: i.string(),
      authorId: i.string(),
      timestamp: i.number().indexed(),
      parentCommentId: i.string().optional(),
    }),
    votes: i.entity({
      userId: i.string(),
      voteType: i.string(),
    }),
  },
  links: {
    postComments: {
      forward: { on: "comments", has: "one", label: "post" },
      reverse: { on: "posts", has: "many", label: "comments" },
    },
    votePost: {
      forward: { on: "votes", has: "one", label: "post" },
      reverse: { on: "posts", has: "many", label: "votes" },
    },
    voteComment: {
      forward: { on: "votes", has: "one", label: "comment" },
      reverse: { on: "comments", has: "many", label: "votes" },
    },
  },
});

// Initialize InstantDB connection
const APP_ID = instantAppId;
const db = init({ appId: APP_ID, schema });

// Type definitions from schema
type Schema = typeof schema;
type Post = InstaQLEntity<Schema, "posts", { comments: {}; votes: {} }>;
type Comment = InstaQLEntity<Schema, "comments", { votes: {} }>;
type Vote = InstaQLEntity<Schema, "votes">;

// ============================================================================
// INSTANT DB OPERATIONS - Real-time, reactive, and multiplayer by default
// ============================================================================

// Create a new post - instantly synced across all clients
function createPost(title: string, body: string, authorId: string) {
  db.transact(
    db.tx.posts[id()].create({
      title,
      body,
      authorId,
      timestamp: Date.now(),
    })
  );
}

// Create multiple posts in a single transaction
function createPosts(
  posts: { title: string; body: string; authorId: string }[]
) {
  const transactions = posts.map((post) =>
    db.tx.posts[id()].create({
      title: post.title,
      body: post.body,
      authorId: post.authorId,
      timestamp: Date.now(),
    })
  );
  db.transact(transactions);
}

// Create a comment with automatic relationship linking
function createComment(
  text: string,
  postId: string,
  authorId: string,
  parentCommentId?: string
) {
  const commentId = id();
  db.transact([
    db.tx.comments[commentId].create({
      text,
      authorId,
      timestamp: Date.now(),
      ...(parentCommentId && { parentCommentId }),
    }),
    // Link comment to post - InstantDB handles the relationship
    db.tx.comments[commentId].link({ post: postId }),
  ]);
}

// Handle creating, updating, or removing a vote
function handleVote(
  targetId: string,
  userId: string,
  voteType: "up" | "down",
  targetType: "post" | "comment",
  existingVote?: Vote
) {
  if (existingVote) {
    if (existingVote.voteType === voteType) {
      db.transact(db.tx.votes[existingVote.id].delete());
    } else {
      db.transact(db.tx.votes[existingVote.id].update({ voteType }));
    }
  } else {
    const voteId = id();
    const linkKey = targetType === "post" ? "post" : "comment";
    db.transact([
      db.tx.votes[voteId].create({ userId, voteType }),
      db.tx.votes[voteId].link({ [linkKey]: targetId }),
    ]);
  }
}

// ============================================================================
// MAIN APP - Demonstrates real-time queries and local-first identity
// ============================================================================

function App() {
  // Local-first user identity - persists across sessions
  const localId = db.useLocalId("guest");

  const [username, setUsername] = useState("");
  const [selectedPost, setSelectedPost] = useState<string | null>(null);
  const [showNewPost, setShowNewPost] = useState(false);

  useEffect(() => {
    const seedPosts = async () => {
      // If need to query inside useEffect, use queryOnce for one-time fetch
      const { data } = await db.queryOnce({ posts: {} });
      if (data.posts.length === 0) {
        createPosts([
          {
            title: "Try it out!",
            body: "Create posts, comment, and vote to see real-time collaboration in action.",
            authorId: "manyminiapps",
          },
          {
            title: "Welcome to InstaReddit!",
            body: "This is a minimal Reddit clone built with InstantDB.",
            authorId: "manyminiapps",
          },
        ]);
      }
    };

    seedPosts();
  }, []);

  // Real-time query - automatically updates when any client makes changes
  const { isLoading, error, data } = db.useQuery({
    posts: {
      $: { order: { timestamp: "desc" } },
      comments: {
        votes: {}, // Nested relationship loading
      },
      votes: {}, // Load votes with posts for instant vote counts
    },
  });

  if (isLoading) return null;
  if (error)
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Error: {error.message}</Text>
      </View>
    );

  const posts = data?.posts || [];
  const currentUsername = username || localId?.slice(0, 8) || "anon";

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View style={styles.headerLeft}>
            {selectedPost && (
              <TouchableOpacity
                onPress={() => setSelectedPost(null)}
                style={styles.backButton}
              >
                <Text style={styles.backButtonText}>← Back</Text>
              </TouchableOpacity>
            )}
            <Text style={styles.title}>InstaReddit</Text>
          </View>
          <View style={styles.headerRight}>
            <TextInput
              placeholder="Set username"
              value={username}
              onChangeText={setUsername}
              style={styles.usernameInput}
            />
            {!selectedPost && (
              <TouchableOpacity
                onPress={() => setShowNewPost(true)}
                style={styles.newPostButton}
              >
                <Text style={styles.newPostButtonText}>New Post</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>
      </View>

      <ScrollView style={styles.main}>
        {selectedPost ? (
          <PostDetail postId={selectedPost} currentUser={currentUsername} />
        ) : (
          <View style={styles.postList}>
            {posts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                currentUser={currentUsername}
                onClick={() => setSelectedPost(post.id)}
              />
            ))}
          </View>
        )}
      </ScrollView>

      {showNewPost && (
        <Modal onClose={() => setShowNewPost(false)}>
          <NewPostForm
            authorId={currentUsername}
            onSubmit={() => setShowNewPost(false)}
          />
        </Modal>
      )}
    </View>
  );
}

function PostDetail({
  postId,
  currentUser,
}: {
  postId: string;
  currentUser: string;
}) {
  // Focused query for single post with all relationships
  const { data } = db.useQuery({
    posts: {
      $: { where: { id: postId } },
      comments: {
        votes: {}, // Load votes for each comment
      },
      votes: {}, // Load votes for the post
    },
  });

  const post = data?.posts?.[0];
  if (!post)
    return (
      <View style={styles.notFound}>
        <Text style={styles.notFoundText}>Post not found</Text>
      </View>
    );

  const votes = getVoteCount(post.votes || []);
  const userVote = getUserVote(post.votes || [], currentUser);
  const topLevelComments = (post.comments || []).filter(
    (c) => !c.parentCommentId
  );

  return (
    <View style={styles.postDetail}>
      <View style={styles.postDetailHeader}>
        <View style={styles.postDetailContent}>
          <VoteButtons
            votes={votes}
            userVote={userVote}
            onVote={(type, existingVote) =>
              handleVote(post.id, currentUser, type, "post", existingVote)
            }
          />
          <View style={styles.postDetailBody}>
            <Text style={styles.postDetailTitle}>{post.title}</Text>
            <Text style={styles.postDetailText}>{post.body}</Text>
            <Text style={styles.postDetailMeta}>
              Posted by {post.authorId} • {formatTime(post.timestamp)}
            </Text>
          </View>
        </View>
      </View>

      <View style={styles.commentsSection}>
        <View style={styles.commentsHeader}>
          <Text style={styles.commentsTitle}>
            {post.comments?.length || 0} Comments
          </Text>
          <NewCommentForm postId={post.id} authorId={currentUser} />
        </View>

        <View style={styles.commentsList}>
          {topLevelComments.map((comment) => (
            <CommentThread
              key={comment.id}
              comment={comment}
              allComments={post.comments || []}
              currentUser={currentUser}
              postId={post.id}
            />
          ))}
        </View>
      </View>
    </View>
  );
}

// ============================================================================
// UI COMPONENTS - Presentation layer that reacts to InstantDB state
// ============================================================================

function PostCard({
  post,
  currentUser,
  onClick,
}: {
  post: Post;
  currentUser: string;
  onClick: () => void;
}) {
  const votes = getVoteCount(post.votes || []);
  const userVote = getUserVote(post.votes || [], currentUser);

  return (
    <TouchableOpacity style={styles.postCard} onPress={onClick}>
      <View style={styles.postCardContent}>
        <VoteButtons
          votes={votes}
          userVote={userVote}
          onVote={(type, existingVote) =>
            handleVote(post.id, currentUser, type, "post", existingVote)
          }
        />
        <View style={styles.postCardBody}>
          <Text style={styles.postCardTitle}>{post.title}</Text>
          <Text style={styles.postCardText} numberOfLines={2}>
            {post.body}
          </Text>
          <Text style={styles.postCardMeta}>
            by {post.authorId} • {formatTime(post.timestamp)} •{" "}
            {post.comments?.length || 0} comments
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

function CommentThread({
  comment,
  allComments,
  currentUser,
  postId,
}: {
  comment: Comment;
  allComments: Comment[];
  currentUser: string;
  postId: string;
}) {
  const [showReply, setShowReply] = useState(false);
  const votes = getVoteCount(comment.votes || []);
  const userVote = getUserVote(comment.votes || [], currentUser);
  const replies = allComments.filter((c) => c.parentCommentId === comment.id);

  return (
    <View style={styles.commentThread}>
      <View style={styles.commentContent}>
        <VoteButtons
          votes={votes}
          userVote={userVote}
          onVote={(type, existingVote) =>
            handleVote(comment.id, currentUser, type, "comment", existingVote)
          }
          small
        />
        <View style={styles.commentBody}>
          <Text style={styles.commentMeta}>
            {comment.authorId} • {formatTime(comment.timestamp)}
          </Text>
          <Text style={styles.commentText}>{comment.text}</Text>
          <TouchableOpacity
            onPress={() => setShowReply(!showReply)}
            style={styles.replyButton}
          >
            <Text style={styles.replyButtonText}>reply</Text>
          </TouchableOpacity>
          {showReply && (
            <View style={styles.replyForm}>
              <NewCommentForm
                postId={postId}
                authorId={currentUser}
                parentCommentId={comment.id}
                onSubmit={() => setShowReply(false)}
              />
            </View>
          )}
        </View>
      </View>
      {replies.length > 0 && (
        <View style={styles.replies}>
          {replies.map((reply) => (
            <View key={reply.id} style={styles.reply}>
              <View style={styles.replyContent}>
                <VoteButtons
                  votes={getVoteCount(reply.votes || [])}
                  userVote={getUserVote(reply.votes || [], currentUser)}
                  onVote={(type, existingVote) =>
                    handleVote(
                      reply.id,
                      currentUser,
                      type,
                      "comment",
                      existingVote
                    )
                  }
                  small
                />
                <View style={styles.replyBody}>
                  <Text style={styles.commentMeta}>
                    {reply.authorId} • {formatTime(reply.timestamp)}
                  </Text>
                  <Text style={styles.commentText}>{reply.text}</Text>
                </View>
              </View>
            </View>
          ))}
        </View>
      )}
    </View>
  );
}

function VoteButtons({
  votes,
  userVote,
  onVote,
  small = false,
}: {
  votes: number;
  userVote: Vote | null;
  onVote: (type: "up" | "down", existingVote?: Vote) => void;
  small?: boolean;
}) {
  const voteType = userVote?.voteType;

  return (
    <View style={styles.voteButtons}>
      <TouchableOpacity
        onPress={(e) => {
          e?.stopPropagation?.();
          onVote("up", userVote || undefined);
        }}
        style={styles.voteButton}
      >
        <Text
          style={[
            styles.voteIcon,
            small && styles.voteIconSmall,
            voteType === "up" && styles.voteIconActive,
          ]}
        >
          ▲
        </Text>
      </TouchableOpacity>
      <Text style={[styles.voteCount, small && styles.voteCountSmall]}>
        {votes}
      </Text>
      <TouchableOpacity
        onPress={(e) => {
          e?.stopPropagation?.();
          onVote("down", userVote || undefined);
        }}
        style={styles.voteButton}
      >
        <Text
          style={[
            styles.voteIcon,
            small && styles.voteIconSmall,
            voteType === "down" && styles.voteIconActiveDown,
          ]}
        >
          ▼
        </Text>
      </TouchableOpacity>
    </View>
  );
}

function NewPostForm({
  authorId,
  onSubmit,
}: {
  authorId: string;
  onSubmit: () => void;
}) {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");

  const handleSubmit = () => {
    if (!title.trim() || !body.trim()) return;

    createPost(title.trim(), body.trim(), authorId);
    onSubmit();
  };

  return (
    <View style={styles.formContainer}>
      <Text style={styles.formTitle}>Create Post</Text>
      <TextInput
        placeholder="Title"
        value={title}
        onChangeText={setTitle}
        style={styles.input}
        autoFocus
      />
      <TextInput
        placeholder="Text (optional)"
        value={body}
        onChangeText={setBody}
        style={[styles.input, styles.textArea]}
        multiline
      />
      <View style={styles.formButtons}>
        <TouchableOpacity onPress={handleSubmit} style={styles.submitButton}>
          <Text style={styles.submitButtonText}>Post</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={onSubmit} style={styles.cancelButton}>
          <Text style={styles.cancelButtonText}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

function NewCommentForm({
  postId,
  authorId,
  parentCommentId,
  onSubmit,
}: {
  postId: string;
  authorId: string;
  parentCommentId?: string;
  onSubmit?: () => void;
}) {
  const [text, setText] = useState("");

  const handleSubmit = () => {
    if (!text.trim()) return;

    createComment(text.trim(), postId, authorId, parentCommentId);
    setText("");
    onSubmit?.();
  };

  return (
    <View style={styles.commentForm}>
      <TextInput
        placeholder={
          parentCommentId ? "Write a reply..." : "Write a comment..."
        }
        value={text}
        onChangeText={setText}
        style={styles.commentInput}
      />
      <TouchableOpacity
        onPress={handleSubmit}
        style={styles.commentSubmitButton}
      >
        <Text style={styles.commentSubmitText}>
          {parentCommentId ? "Reply" : "Comment"}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

function Modal({
  children,
  onClose,
}: {
  children: React.ReactNode;
  onClose: () => void;
}) {
  return (
    <View style={styles.modalOverlay}>
      <View style={styles.modalContent}>
        <View style={styles.modalInner}>
          <TouchableOpacity onPress={onClose} style={styles.modalClose}>
            <Text style={styles.modalCloseText}>×</Text>
          </TouchableOpacity>
          {children}
        </View>
      </View>
    </View>
  );
}

// ============================================================================
// UTILITY FUNCTIONS - Pure functions for data transformation
// ============================================================================

function getVoteCount(votes: Vote[]): number {
  const upvotes = votes.filter((v) => v.voteType === "up").length;
  const downvotes = votes.filter((v) => v.voteType === "down").length;
  return upvotes - downvotes;
}

function getUserVote(votes: Vote[], userId: string): Vote | null {
  return votes.find((v) => v.userId === userId) || null;
}

function formatTime(timestamp: number): string {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

// ============================================================================
// STYLESHEET - React Native styles
// ============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f3f4f6",
  },
  errorContainer: {
    padding: 16,
  },
  errorText: {
    color: "#ef4444",
  },
  header: {
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#d1d5db",
  },
  headerContent: {
    paddingHorizontal: 8,
    paddingVertical: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  backButton: {
    padding: 4,
  },
  backButtonText: {
    color: "#4b5563",
    fontSize: 14,
  },
  title: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#f97316",
  },
  headerRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  usernameInput: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    fontSize: 14,
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 4,
  },
  newPostButton: {
    paddingHorizontal: 16,
    paddingVertical: 4,
    backgroundColor: "#f97316",
    borderRadius: 4,
  },
  newPostButtonText: {
    color: "#fff",
  },
  main: {
    flex: 1,
    padding: 16,
  },
  postList: {
    gap: 12,
  },
  postCard: {
    backgroundColor: "#fff",
    borderRadius: 4,
    borderWidth: 1,
    borderColor: "#d1d5db",
    padding: 16,
    marginBottom: 12,
  },
  postCardContent: {
    flexDirection: "row",
    gap: 12,
  },
  postCardBody: {
    flex: 1,
  },
  postCardTitle: {
    fontWeight: "600",
    fontSize: 18,
    marginBottom: 4,
  },
  postCardText: {
    color: "#4b5563",
    fontSize: 14,
    marginBottom: 8,
  },
  postCardMeta: {
    fontSize: 12,
    color: "#6b7280",
  },
  notFound: {
    padding: 16,
  },
  notFoundText: {
    color: "#6b7280",
  },
  postDetail: {
    backgroundColor: "#fff",
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#d1d5db",
  },
  postDetailHeader: {
    padding: 24,
    borderBottomWidth: 1,
    borderBottomColor: "#d1d5db",
  },
  postDetailContent: {
    flexDirection: "row",
    gap: 16,
  },
  postDetailBody: {
    flex: 1,
  },
  postDetailTitle: {
    fontWeight: "bold",
    fontSize: 24,
    marginBottom: 12,
  },
  postDetailText: {
    color: "#374151",
    marginBottom: 16,
  },
  postDetailMeta: {
    fontSize: 14,
    color: "#6b7280",
  },
  commentsSection: {
    padding: 24,
  },
  commentsHeader: {
    marginBottom: 24,
  },
  commentsTitle: {
    fontWeight: "600",
    marginBottom: 12,
  },
  commentsList: {
    gap: 16,
  },
  commentThread: {
    borderLeftWidth: 2,
    borderLeftColor: "#e5e7eb",
    paddingLeft: 12,
  },
  commentContent: {
    flexDirection: "row",
    gap: 8,
  },
  commentBody: {
    flex: 1,
  },
  commentMeta: {
    fontSize: 12,
    color: "#6b7280",
    marginBottom: 4,
  },
  commentText: {
    fontSize: 14,
  },
  replyButton: {
    marginTop: 4,
  },
  replyButtonText: {
    fontSize: 12,
    color: "#3b82f6",
  },
  replyForm: {
    marginTop: 8,
  },
  replies: {
    marginTop: 12,
    gap: 12,
  },
  reply: {
    paddingLeft: 12,
  },
  replyContent: {
    flexDirection: "row",
    gap: 8,
  },
  replyBody: {
    flex: 1,
  },
  voteButtons: {
    alignItems: "center",
    gap: 4,
  },
  voteButton: {
    padding: 4,
  },
  voteIcon: {
    fontSize: 18,
    color: "#9ca3af",
  },
  voteIconSmall: {
    fontSize: 14,
  },
  voteIconActive: {
    color: "#f97316",
  },
  voteIconActiveDown: {
    color: "#3b82f6",
  },
  voteCount: {
    fontSize: 14,
    fontWeight: "600",
  },
  voteCountSmall: {
    fontSize: 12,
  },
  formContainer: {
    padding: 16,
  },
  formTitle: {
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 12,
  },
  input: {
    width: "100%",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 4,
    marginBottom: 12,
  },
  textArea: {
    height: 128,
    textAlignVertical: "top",
  },
  formButtons: {
    flexDirection: "row",
    gap: 8,
  },
  submitButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: "#f97316",
    borderRadius: 4,
  },
  submitButtonText: {
    color: "#fff",
  },
  cancelButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 4,
  },
  cancelButtonText: {
    color: "#374151",
  },
  commentForm: {
    flexDirection: "row",
    gap: 8,
  },
  commentInput: {
    flex: 1,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 4,
    fontSize: 14,
  },
  commentSubmitButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: "#3b82f6",
    borderRadius: 4,
  },
  commentSubmitText: {
    color: "#fff",
    fontSize: 14,
  },
  modalOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
    padding: 16,
  },
  modalContent: {
    backgroundColor: "#fff",
    borderRadius: 8,
    maxWidth: 600,
    width: "100%",
    maxHeight: "90%",
    overflow: "hidden",
  },
  modalInner: {
    position: "relative",
  },
  modalClose: {
    position: "absolute",
    top: 8,
    right: 8,
    zIndex: 1,
  },
  modalCloseText: {
    fontSize: 32,
    color: "#6b7280",
  },
});

export default App;
