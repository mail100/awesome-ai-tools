// 简单的内存存储，用于实时同步生成状态
interface GenerationState {
  [key: string]: {
    codeSoFar: string;
    isComplete: boolean;
    error?: string;
    generationTime?: number;
  };
}

const store: GenerationState = {};

export function setGenerationState(
  id: string,
  codeSoFar: string,
  isComplete: boolean,
  error?: string,
  generationTime?: number
) {
  store[id] = {
    codeSoFar,
    isComplete,
    error,
    generationTime,
  };
}

export function getGenerationState(id: string) {
  return store[id];
}

export function clearGenerationState(id: string) {
  delete store[id];
}
