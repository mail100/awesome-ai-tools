# AI 代码执行机制完全指南

从零理解如何让 AI 生成的代码"活"过来运行

本文档面向初学者，循序渐进地讲解本项目如何实现 AI 生成代码的直接运行。不需要深厚的基础，只要会基本的 JavaScript 就能看懂。

## 目录

- [第一章：问题与目标](#第一章问题与目标)
- [第二章：核心思路](#第二章核心思路)
- [第三章：逐步实现](#第三章逐步实现)
- [第四章：最难理解的部分 - 深度解析](#第四章最难理解的部分---深度解析)
- [第五章：完整流程演示](#第五章完整流程演示)
- [第六章：安全性分析](#第六章安全性分析)
- [第七章：局限性](#第七章局限性)
- [第八章：实战示例](#第八章实战示例)

---

## 第一章：问题与目标

### 1.1 我们要解决什么问题？

想象一下，用户对 AI 说："帮我做一个待办事项应用"

AI 回复了一段代码：

```typescript
import React from 'react';
import { View, Text } from 'react-native';

export default App = () => {
  return <View><Text>我的待办</Text></View>;
};
```

**问题来了**：这段代码只是一个**字符串**，怎么让它真正运行起来？

### 1.2 为什么这么难？

正常情况下，React Native 代码需要经历这个流程：

```mermaid
flowchart LR
    A[写代码] --> B[保存文件]
    B --> C[打包编译]
    C --> D[生成 bundle]
    D --> E[运行应用]

    style A fill:#e1f5fe
    style E fill:#c8e6c9
```

这个过程需要几分钟，而且每次改代码都要重新编译。

**我们想要的效果**：

```mermaid
flowchart LR
    A[AI 生成代码字符串] --> B[立即运行]

    style A fill:#e1f5fe
    style B fill:#c8e6c9
```

无需编译，无需重启，**立即**在屏幕上看到效果！

### 1.3 核心挑战

要让 AI 生成的代码字符串运行起来，我们需要解决三个问题：

1. **代码格式问题**：AI 可能生成 TypeScript、JSX，浏览器/手机不能直接运行
2. **模块导入问题**：代码里有 `import`，但这段代码不在文件系统里
3. **安全问题**：不能让 AI 生成的代码随意访问系统资源

---

## 第二章：核心思路

### 2.1 三步走战略

```mermaid
flowchart TD
    A[AI 生成的代码字符串] --> B[步骤1: 转换代码格式<br/>Babel 把 JSX/TS 变成纯 JS]
    B --> C[步骤2: 模拟模块系统<br/>提供一个假的 require 函数]
    C --> D[步骤3: 动态执行代码<br/>用 Function 构造器运行]
    D --> E[得到可运行的 React 组件]

    style A fill:#e1f5fe
    style E fill:#c8e6c9
```

### 2.2 一个简单的类比

想象你要在一张白纸上画一幅画：

1. **准备画笔**（转译）：把铅笔稿转换成可以上色的格式
2. **准备颜料**（模块注入）：只提供你允许使用的颜色
3. **开始作画**（执行）：让画画的人真正动手画

这就是我们整个流程的核心思想！

---

## 第三章：逐步实现

### 3.1 步骤 1：代码格式转换 - Babel 的魔法

**问题**：AI 生成的代码可能长这样：

```typescript
// AI 的代码
import React from 'react';
import { View, Text } from 'react-native';

export default App = (props: { name: string }) => {
  return <View>Hello {props.name}</View>;
};
```

这段代码有三个问题：
- 有 JSX（`<View>`）
- 有 TypeScript 类型（`: { name: string }`）
- 有 ES6 模块（`import`）

**解决**：用 Babel 转换！

```mermaid
flowchart LR
    subgraph 输入["原始代码"]
        A1["JSX 语法"]
        A2["TypeScript 类型"]
        A3["ES6 import"]
    end

    subgraph Babel["Babel 转换器"]
        B["处理中..."]
    end

    subgraph 输出["转译后"]
        C1["React.createElement"]
        C2["普通 JavaScript"]
        C3["require 语句"]
    end

    输入 --> B --> 输出

    style 输入 fill:#e1f5fe
    style 输出 fill:#c8e6c9
```

**代码实现**：

```typescript
import * as Babel from '@babel/standalone';

const transformed = Babel.transform(code, {
  presets: [
    ['env', { targets: { esmodules: true } }],  // 处理现代 JS 特性
    'react',                                    // 把 JSX 变成 React.createElement
    'typescript'                                // 移除类型注解
  ],
  plugins: [['transform-modules-commonjs']]      // 把 import 变成 require
}).code;
```

**转换结果**：

```javascript
// 转换后的代码
const React = require('react');
const ReactNative = require('react-native');

const App = (props) => {
  return React.createElement(ReactNative.View, null, "Hello ", props.name);
};
```

### 3.2 步骤 2：模拟模块系统 - 假的 require

现在代码变成了 `require('react')`，但问题是：

**这段代码不在文件系统里！** 它只是一个字符串，Node.js 的 `require` 根本找不到这些模块。

**解决方案**：我们自己写一个 `require` 函数！

```typescript
const require = (moduleName) => {
  if (moduleName === 'react') {
    return React;  // 返回我们已经导入的 React
  }
  if (moduleName === 'react-native') {
    return ReactNative;  // 返回我们已经导入的 React Native
  }
  if (moduleName === '@instantdb/react-native') {
    return Instant;  // 返回我们已经导入的 InstantDB
  }

  // 其他模块一律拒绝！
  throw new Error('Module not found: ' + moduleName);
};
```

这就是**白名单机制**：只允许访问我们明确允许的模块。

```mermaid
flowchart TD
    A[代码调用 require] --> B{模块名称?}
    B -->|react| C[返回 React]
    B -->|react-native| D[返回 ReactNative]
    B -->|@instantdb/react-native| E[返回 Instant]
    B -->|其他| F[抛出错误]

    style C fill:#c8e6c9
    style D fill:#c8e6c9
    style E fill:#c8e6c9
    style F fill:#ffcdd2
```

### 3.3 步骤 3：模拟 CommonJS 模块导出

这部分代码最容易让人困惑，让我们深入理解每一行！

#### 为什么需要 `exports` 和 `module.exports`？

在 Node.js 中，每个文件都被当作一个模块，Node.js 会自动给每个模块提供这些变量：

```javascript
// Node.js 自动给你的代码加了这些
const exports = module.exports;
```

但我们的代码不在文件系统里，没有 Node.js 帮忙，所以需要**自己模拟**！

#### 逐步拆解

```typescript
const moduleCode = `
  // 第一步：创建假的 module 对象
  const exports = {};
  const module = { exports };

  // 第二步：提供我们自定义的 require 函数
  const require = (name) => {
    if (name === 'react') return React;
    if (name === 'react-native') return ReactNative;
    if (name === '@instantdb/react-native') return Instant;
    throw new Error('Module not found: ' + name);
  };

  // 第三步：把转译后的代码插进来
  ${transformed}

  // 第四步：返回这个模块导出的内容
  return module.exports.default || module.exports;
`;
```

让我们用动画来理解这个过程：

```mermaid
flowchart TD
    A["创建空对象 exports = {}"] --> B["创建 module 对象<br/>module = { exports }"]
    B --> C["module.exports 指向 exports"]
    C --> D["AI 代码运行<br/>可能会修改 module.exports"]
    D --> E["返回 module.exports.default"]

    style A fill:#e1f5fe
    style B fill:#e3f2fd
    style C fill:#c8e6c9
    style D fill:#fff9c4
    style E fill:#c8e6c9
```

#### 详解 `require` 函数的工作原理

`require` 函数是这个系统的核心，让我们详细看它是如何工作的：

```typescript
const require = (name) => {
  // 当 AI 代码里调用 require('react') 时
  if (name === 'react') {
    return React;  // 返回我们传入的真实 React 对象
  }

  // 当 AI 代码里调用 require('react-native') 时
  if (name === 'react-native') {
    return ReactNative;  // 返回我们传入的真实 ReactNative 对象
  }

  // 当 AI 代码里调用 require('@instantdb/react-native') 时
  if (name === '@instantdb/react-native') {
    return Instant;  // 返回我们传入的真实 InstantDB 对象
  }

  // 其他任何模块都拒绝访问！
  throw new Error('Module not found: ' + name);
};
```

**这个过程可以用图表示**：

```mermaid
flowchart TD
    A["AI 代码: require('react')"] --> B{检查模块名}
    B -->|'react'| C["返回 React 参数"]
    B -->|'react-native'| D["返回 ReactNative 参数"]
    B -->|'@instantdb/react-native'| E["返回 Instant 参数"]
    B -->|其他| F["抛出错误 ❌"]

    C --> G["AI 代码获得真实的 React"]
    D --> G
    E --> G

    style C fill:#c8e6c9
    style D fill:#c8e6c9
    style E fill:#c8e6c9
    style F fill:#ffcdd2
    style G fill:#e1f5fe
```

#### 一个完整的例子

让我们看一个完整的例子来理解整个流程：

**假设 AI 生成的代码是**：

```typescript
import React from 'react';
import { View } from 'react-native';

export default App = () => {
  return <View>Hello</View>;
};
```

**Babel 转译后会变成**：

```javascript
const React = require('react');
const ReactNative = require('react-native');

const App = () => {
  return React.createElement(ReactNative.View, null, "Hello");
};

module.exports.default = App;
```

**现在在我们的 `moduleCode` 里执行**：

```javascript
// 1. 创建模块系统
const exports = {};
const module = { exports };

// 2. 定义 require
const require = (name) => {
  if (name === 'react') return React;  // 这里的 React 是外部传入的参数！
  if (name === 'react-native') return ReactNative;  // 同理！
  throw new Error('Module not found: ' + name);
};

// 3. 执行转译后的代码（就是 ${transformed} 部分）
const React = require('react');
// 上面这行调用 require('react')
// require 函数检查参数是 'react'
// 返回外部传入的 React 对象
// 现在 React 变量就指向真实的 React 了！

const ReactNative = require('react-native');
// 同理，现在 ReactNative 也指向真实的 ReactNative 了！

const App = () => {
  return React.createElement(ReactNative.View, null, "Hello");
};
// 现在 App 函数可以正常运行了！
// 因为它用的 React 和 ReactNative 都是真实的对象

module.exports.default = App;
// 把 App 函数赋值给 module.exports.default

// 4. 返回导出的内容
return module.exports.default || module.exports;
// 返回 App 函数！
```

#### 关键理解点

```mermaid
mindmap
  root((模块系统模拟))
    exports
      空对象 {}
      用于存储导出内容
    module.exports
      指向 exports
      Node.js 标准做法
    require 函数
      拦截所有 require 调用
      返回外部传入的真实对象
      实现白名单安全机制
    参数传递
      React 通过函数参数传入
      require 返回这个参数
      AI 代码获得真实对象
```

**最重要的理解**：

1. `const module = { exports }` 创建了一个对象，它的 `exports` 属性指向 `exports` 对象
2. 当 AI 代码执行 `module.exports.default = App` 时，实际上是把 `App` 放到了这个对象里
3. 最后我们返回 `module.exports.default`，就是返回 AI 导出的组件
4. `require` 函数是一个"桥梁"，把外部传入的 React/ReactNative 对象"桥接"给 AI 代码使用

#### 为什么不能直接用 `exports`？

你可能问：为什么不直接 `const exports = { default: App }`？

因为这是**模拟 Node.js 的模块系统**，Node.js 的代码（Babel 转译后的）期望的是 `module.exports` 这个结构：

```javascript
// Babel 期望能这样做
module.exports.default = App;

// 而不是
exports = App;  // 这样不行！
```

所以我们必须提供 `module.exports` 这个接口，即使它看起来有点绕。

---

#### 总结：这个模拟系统的三个角色

```mermaid
graph LR
    subgraph 角色1["exports 和 module"]
        A1["exports = {}"]
        A2["module = { exports }"]
        A2 --> A1
    end

    subgraph 角色2["require 函数"]
        B1["拦截模块请求"]
        B2["返回真实对象"]
        B3["白名单安全检查"]
    end

    subgraph 角色3["外部参数"]
        C1["React 对象"]
        C2["ReactNative 对象"]
        C3["Instant 对象"]
    end

    A2 --> D["AI 代码使用"]
    B1 --> C1
    B1 --> C2
    B1 --> C3
    C1 --> D
    C2 --> D
    C3 --> D

    style 角色1 fill:#e3f2fd
    style 角色2 fill:#fff9c4
    style 角色3 fill:#c8e6c9
```

这三个角色配合起来，就创造了一个**迷你版的 Node.js 模块系统**！

---

## 第四章：最难理解的部分 - 深度解析

这一章我们详细讲解最核心、最难理解的代码：

```typescript
const moduleFn = new Function('React', 'ReactNative', 'Instant', moduleCode);
const Component = moduleFn(React, ReactNative, Instant);
return React.createElement(Component);
```

### 4.1 什么是 `Function` 构造器？

**你可能知道**：可以这么定义函数

```typescript
function add(a, b) {
  return a + b;
}
```

**但你知道吗**：还有一种方式叫 `Function` 构造器

```typescript
const add = new Function('a', 'b', 'return a + b');
```

这两种写法**完全等价**！

```mermaid
flowchart LR
    subgraph 传统方式
        A1["function add(a, b)"]
        A2["{ return a + b; }"]
    end

    subgraph Function构造器
        B1["new Function"]
        B2["'a', 'b'"]
        B3["'return a + b'"]
    end

    传统方式 --> Function构造器

    style 传统方式 fill:#e3f2fd
    style Function构造器 fill:#fff9c4
```

**为什么要用 `Function` 构造器？**

因为我们的代码在**字符串**里，不是在文件里！

```typescript
// 这是字符串
const codeString = "return a + b";

// 可以用 Function 构造器把它变成可执行的函数
const addFunction = new Function('a', 'b', codeString);
addFunction(1, 2);  // 返回 3
```

### 4.2 逐步拆解我们的代码

让我们从头到尾拆解这段神秘的代码：

#### 第一步：构建 `moduleCode` 字符串

```typescript
const moduleCode = `
  const exports = {};
  const module = { exports };

  const require = (name) => {
    if (name === 'react') return React;
    if (name === 'react-native') return ReactNative;
    if (name === '@instantdb/react-native') return Instant;
    throw new Error('Module not found: ' + name);
  };

  ${transformed}

  return module.exports.default || module.exports;
`;
```

这个字符串看起来像什么？

**展开后实际上是这样**（假设 `transformed` 是转译后的代码）：

```javascript
const exports = {};
const module = { exports };

const require = (name) => {
  if (name === 'react') return React;
  if (name === 'react-native') return ReactNative;
  if (name === '@instantdb/react-native') return Instant;
  throw new Error('Module not found: ' + name);
};

const React = require('react');
const ReactNative = require('react-native');

const App = (props) => {
  return React.createElement(ReactNative.View, null, "Hello");
};

module.exports.default = App;

return module.exports.default || module.exports;
```

#### 第二步：创建函数工厂

```typescript
const moduleFn = new Function('React', 'ReactNative', 'Instant', moduleCode);
```

这句话做了什么？

它创建了一个**函数工厂**，这个函数：

- 接收 3 个参数：`React`、`ReactNative`、`Instant`
- 函数体就是 `moduleCode` 字符串里的内容

**等价于**：

```typescript
function moduleFn(React, ReactNative, Instant) {
  const exports = {};
  const module = { exports };

  const require = (name) => {
    if (name === 'react') return React;  // 注意：这里的 React 是参数！
    if (name === 'react-native') return ReactNative;  // 也是参数！
    if (name === '@instantdb/react-native') return Instant;  // 也是参数！
    throw new Error('Module not found: ' + name);
  };

  // ... 转译后的代码 ...

  return module.exports.default || module.exports;
}
```

#### 第三步：调用函数，获取组件

```typescript
const Component = moduleFn(React, ReactNative, Instant);
```

这一步：

1. 调用 `moduleFn` 函数
2. 传入真实的 `React`、`ReactNative`、`Instant` 对象
3. 函数内部执行，最终返回 `module.exports.default`
4. `module.exports.default` 就是 AI 生成的那个 `App` 组件！

```mermaid
sequenceDiagram
    participant Main as 主程序
    participant Factory as moduleFn 函数工厂
    participant Sandbox as 沙箱执行环境

    Main->>Factory: new Function 创建
    Factory-->>Main: 返回函数

    Main->>Factory: moduleFn(React, ReactNative, Instant)
    activate Factory
    Factory->>Sandbox: 创建沙箱环境
    Sandbox->>Sandbox: 执行 AI 代码
    Sandbox-->>Factory: 返回导出的组件
    Factory-->>Main: 返回 Component
    deactivate Factory
```

### 4.3 一个完整的例子

让我们看一个完整的例子来理解整个过程：

**假设 AI 生成了这段代码**：

```typescript
import React from 'react';
import { View, Text } from 'react-native';

export default App = () => {
  return <View><Text>Hello World</Text></View>;
};
```

**步骤 1：Babel 转译**

```javascript
const React = require('react');
const ReactNative = require('react-native');

const App = () => {
  return React.createElement(ReactNative.View, null,
    React.createElement(ReactNative.Text, null, "Hello World")
  );
};

module.exports.default = App;
```

**步骤 2：构建 moduleCode**

```javascript
const moduleCode = `
  const exports = {};
  const module = { exports };

  const require = (name) => {
    if (name === 'react') return React;
    if (name === 'react-native') return ReactNative;
    if (name === '@instantdb/react-native') return Instant;
    throw new Error('Module not found: ' + name);
  };

  // 插入转译后的代码
  const React = require('react');
  const ReactNative = require('react-native');

  const App = () => {
    return React.createElement(ReactNative.View, null,
      React.createElement(ReactNative.Text, null, "Hello World")
    );
  };

  module.exports.default = App;

  return module.exports.default || module.exports;
`;
```

**步骤 3：创建并调用函数**

```typescript
// 创建函数工厂
const moduleFn = new Function('React', 'ReactNative', 'Instant', moduleCode);

// 调用函数，传入真实的 React 和 ReactNative
const Component = moduleFn(React, ReactNative, Instant);
// Component 现在就是 AI 生成的 App 组件！
```

**步骤 4：创建 React 元素**

```typescript
return React.createElement(Component);
// 现在可以直接渲染了！
```

### 4.4 为什么这么绕？

你可能会问：**为什么不直接 `eval` 执行代码？**

| 方法 | 作用域 | 安全性 | 调试 |
|------|--------|--------|------|
| `eval()` | 可以访问外部变量 | ❌ 很危险 | 困难 |
| `new Function()` | 独立作用域，只能访问参数 | ✅ 相对安全 | 稍好 |

```mermaid
flowchart TD
    A["需要执行字符串代码"] --> B{选择方式}
    B -->|eval| C["可以访问所有外部变量<br/>❌ 不安全"]
    B -->|new Function| D["只能访问传入的参数<br/>✅ 相对安全"]

    style C fill:#ffcdd2
    style D fill:#c8e6c9
```

使用 `new Function` 的好处：

1. **作用域隔离**：AI 代码访问不到我们程序里的其他变量
2. **参数控制**：只有我们显式传入的东西（React、ReactNative 等）才能被访问
3. **更安全**：相当于创建了一个沙箱

### 4.5 整个过程的动画演示

```mermaid
flowchart TD
    A["AI 生成代码字符串"] --> B["Babel 转译"]
    B --> C["构建 moduleCode<br/>嵌入 require 函数"]
    C --> D["new Function 创建函数工厂"]
    D --> E["调用函数<br/>传入 React/ReactNative"]
    E --> F["函数内部执行<br/>require 返回真实模块"]
    F --> G["返回导出的组件"]
    G --> H["React.createElement<br/>创建可渲染元素"]

    style A fill:#e1f5fe
    style H fill:#c8e6c9
```

---

## 第五章：完整流程演示

让我们用一个真实的例子走完整个流程。

### 5.1 输入：AI 生成的代码

```typescript
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default App = () => {
  return (
    <View style={styles.container}>
      <Text>Hello World</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center' }
});
```

### 5.2 完整执行流程

```mermaid
flowchart TD
    A["输入代码字符串"] --> B["步骤1: 替换 instantAppId"]
    B --> C["步骤2: 清理代码边界"]
    C --> D["步骤3: Babel 转译"]
    D --> E["步骤4: 构建 moduleCode"]
    E --> F["步骤5: new Function"]
    F --> G["步骤6: 调用函数获取组件"]
    G --> H["步骤7: createElement"]
    H --> I["输出: 可渲染的 React 元素"]

    style A fill:#e1f5fe
    style I fill:#c8e6c9
```

### 5.3 每一步的详细输出

**步骤 1-2：清理后的代码**
```typescript
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default App = () => {
  return (
    <View style={styles.container}>
      <Text>Hello World</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center' }
});
```

**步骤 3：Babel 转译后**
```javascript
const React = require('react');
const ReactNative = require('react-native');

const App = () => {
  return React.createElement(ReactNative.View, {
    style: styles.container
  }, React.createElement(ReactNative.Text, null, "Hello World"));
};

const styles = ReactNative.StyleSheet.create({
  container: { flex: 1, justifyContent: 'center' }
});

module.exports.default = App;
```

**步骤 4-7：执行后**
- `Component` = `App` 函数组件
- 最终返回 `React.createElement(App)`

### 5.4 在 React 中使用

```typescript
// 在你的应用里
import codeStrToReactElement from '@/utils/codeStrToReactElement';

function BuilderScreen() {
  const aiCode = `...`;  // AI 生成的代码

  // 转换成可渲染的元素
  const element = codeStrToReactElement('app-id-123', aiCode);

  // 直接渲染！
  return element;
}
```

---

## 第六章：安全性分析

### 6.1 白名单机制

我们通过自定义 `require` 函数实现白名单：

```mermaid
flowchart TD
    A[AI 代码尝试导入模块] --> B{检查模块名}
    B -->|react| C["✅ 允许"]
    B -->|react-native| C
    B -->|@instantdb/react-native| C
    B -->|fs| D["❌ 拒绝<br/>无法访问文件系统"]
    B -->|http| D
    B -->|child_process| D
    B -->|crypto| D

    style C fill:#c8e6c9
    style D fill:#ffcdd2
```

### 6.2 安全边界

```typescript
const require = (name) => {
  // ✅ 允许的模块
  if (name === 'react') return React;
  if (name === 'react-native') return ReactNative;
  if (name === '@instantdb/react-native') return Instant;

  // ❌ 其他所有模块都被拒绝
  throw new Error('Module not found: ' + name);
};
```

**这意味着**：
- AI 代码**无法**访问文件系统（`fs`）
- AI 代码**无法**发起网络请求（`http`）
- AI 代码**无法**执行系统命令（`child_process`）
- AI 代码**只能**使用 React、React Native 和 InstantDB

### 6.3 当前安全限制

⚠️ **注意**：虽然有白名单，但仍有一些风险：

```mermaid
mindmap
  root((安全风险))
    全局对象访问
      可能访问 global/window
      可以修改全局原型
    资源消耗
      无限循环
      大对象创建
      内存泄漏
    时间攻击
      复杂计算
      递归调用
```

---

## 第七章：局限性

### 7.1 功能限制

| 限制 | 影响 | 示例 |
|------|------|------|
| 只能用 3 个库 | 无法使用第三方包 | ❌ `import _ from 'lodash'` |
| 单文件 | 不能有模块导入 | ❌ `import utils from './utils'` |
| 无原生模块 | 不能用硬件功能 | ❌ 摄像头、GPS |

### 7.2 性能开销

```mermaid
flowchart LR
    A[代码变更] --> B["Babel 转译<br/>100-500ms"]
    B --> C["Function 创建<br/>10-50ms"]
    C --> D["代码执行<br/>5-20ms"]
    D --> E["渲染<br/>16-60ms"]

    style B fill:#fff9c4
```

Babel 转译占用 **70-90%** 的时间！

### 7.3 调试困难

- ❌ 错误堆栈指向转译后的代码
- ❌ 行号与原始代码不匹配
- ❌ 无法设置断点

---

## 第八章：实战示例

### 8.1 简单示例

```typescript
import codeStrToReactElement from '@/utils/codeStrToReactElement';

// AI 生成的待办应用代码
const todoAppCode = `
import React from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import { init } from '@instantdb/react-native';

const db = init({ instantAppId });

export default App = () => {
  const [text, setText] = React.useState('');
  const { data } = db.useQuery({ todos: {} });

  const addTodo = () => {
    db.transact(db.tx.todos[id].create({ title: text }));
    setText('');
  };

  return (
    <View style={{ padding: 20 }}>
      <TextInput
        value={text}
        onChangeText={setText}
        placeholder="添加待办..."
      />
      <TouchableOpacity onPress={addTodo}>
        <Text>添加</Text>
      </TouchableOpacity>
      {data.todos.map(todo => (
        <Text key={todo.id}>{todo.title}</Text>
      ))}
    </View>
  );
};
`;

// 转换并渲染
export default function AppBuilder() {
  return codeStrToReactElement('my-app-id', todoAppCode);
}
```

### 8.2 在本项目中的应用

```mermaid
flowchart LR
    A[用户输入提示] --> B[AI 生成代码]
    B --> C[codeStrToReactElement]
    C --> D[实时预览]

    E[保存到数据库] --> F[build/id.tsx]
    F --> C

    style A fill:#e1f5fe
    style D fill:#c8e6c9
```

---

## 附录 A：AI System Prompt 详解

这个项目的核心不仅在于动态代码执行机制，还在于如何指导 AI 生成符合规范的代码。[`resources/systemPrompt.txt`](../resources/systemPrompt.txt) 文件定义了 AI 生成代码时必须遵守的规则和最佳实践。

### A.1 System Prompt 的作用

```mermaid
flowchart LR
    A[用户输入需求] --> B[AI + System Prompt]
    B --> C[生成符合规范的代码]
    C --> D[codeStrToReactElement 执行]

    style A fill:#e1f5fe
    style B fill:#fff9c4
    style D fill:#c8e6c9
```

**System Prompt 就像是给 AI 的"编程指南"**，确保生成的代码：
- ✅ 能在我们的动态执行环境中运行
- ✅ 遵循 React 最佳实践
- ✅ 正确使用 InstantDB
- ✅ 代码简洁、可维护

### A.2 核心规则解析

#### 规则 1：技术栈约束

```markdown
You are an expert React Native developer who writes mini apps in InstantDB
using StyleSheet for styling.
```

**为什么这样限制？**

因为我们的沙箱环境只提供了这三个模块：
- `react` - React 框架
- `react-native` - React Native 组件
- `@instantdb/react-native` - InstantDB 数据库

```mermaid
flowchart TD
    A[AI 生成代码] --> B{检查技术栈}
    B -->|React Native| C[✅ 允许]
    B -->|StyleSheet| C
    B -->|InstantDB| C
    B -->|Vue.js| D[❌ 拒绝]
    B -->|Redux| D
    B -->|其他库| D

    style C fill:#c8e6c9
    style D fill:#ffcdd2
```

#### 规则 2：Hooks 规则

```markdown
You ALWAYS follow react's rule of hooks, you NEVER render hooks conditionally.
```

**这是最常见的错误！** ❌

错误的示例：
```typescript
// ❌ 错误：条件渲染 hooks
if (isLoading) {
  const [data, setData] = useState(null);  // 违反 Hooks 规则！
}
```

正确的示例：
```typescript
// ✅ 正确：所有 hooks 都在组件顶层
function App() {
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  if (isLoading) {
    return <Text>Loading...</Text>;
  }
  return <Text>{data}</Text>;
}
```

**为什么这条规则这么重要？**

React 的 Hooks 依赖于**调用顺序**。如果条件渲染，顺序会乱掉，导致 bug！

```mermaid
flowchart LR
    A[第一次渲染] --> B[useState 1]
    B --> C[useState 2]
    C --> D[useEffect]

    E[第二次渲染] --> F[useState 1]
    F --> G[条件跳过 useState 2]
    G --> H[useEffect]

    H --> I["❌ 顺序错乱！React 混淆了"]
```

#### 规则 3：代码长度限制

```markdown
You should keep the code under 500 lines. If you go over, be mindful.
```

**为什么限制 500 行？**

1. **性能考虑**：代码越长，Babel 转译越慢
2. **可读性**：单个文件太长难以维护
3. **专注核心功能**：鼓励 AI 生成简洁的解决方案

```mermaid
flowchart LR
    A[代码行数] --> B{< 500 行?}
    B -->|是| C[✅ 快速转译<br/>✅ 易于维护]
    B -->|否| D[⚠️ 转译变慢<br/>⚠️ 难以调试]

    style C fill:#c8e6c9
    style D fill:#fff9c4
```

### A.3 InstantDB 使用规范

#### 规则 4：必须使用 UUID

```markdown
CRITICAL: When creating or updating entities, you MUST use a UUID as the
entity ID. You can use `id()` from @instantdb/react-native to generate one.
```

**为什么不能用自增 ID？**

因为 InstantDB 是**分布式数据库**，多客户端同时创建数据时，自增 ID 会冲突！

❌ **错误**：
```typescript
// ❌ 不要这样做！
db.tx.todos[1].create({ title: 'Buy milk' });  // 硬编码 ID
db.tx.todos[currentId++].create({ title: 'Buy milk' });  // 自增 ID
```

✅ **正确**：
```typescript
// ✅ 正确做法
import { id } from '@instantdb/react-native';

db.tx.todos[id()].create({ title: 'Buy milk' });  // 自动生成 UUID
```

#### 规则 5：索引和排序

```markdown
CRITICAL: You MUST index any field you want to filter or order by in the schema.
```

这个规则非常重要！没有索引就无法查询或排序。

**Schema 定义示例**：

```typescript
const schema = i.schema({
  entities: {
    todos: i.entity({
      title: i.string(),
      // ✅ indexed 字段可以用于过滤和排序
      createdAt: i.number().indexed(),
      priority: i.number().indexed(),
      // ❌ non-indexed 字段不能用于过滤
      description: i.string(),
    }),
  },
});
```

**查询示例**：

```typescript
// ✅ 可以：按 indexed 字段排序
db.useQuery({
  todos: {
    $: { order: { createdAt: 'desc' } }  // createdAt 是 indexed
  }
});

// ❌ 不行：按 non-indexed 字段排序会报错
db.useQuery({
  todos: {
    $: { order: { title: 'asc' } }  // title 不是 indexed！
  }
});
```

```mermaid
flowchart TD
    A[定义字段] --> B{添加 indexed?}
    B -->|是| C[✅ 可以过滤<br/>✅ 可以排序]
    B -->|否| D[❌ 不能过滤<br/>❌ 不能排序]

    style C fill:#c8e6c9
    style D fill:#ffcdd2
```

### A.4 查询操作符完整指南

System Prompt 提供了 InstantDB 的完整查询操作符：

#### 等值查询

```typescript
// 精确匹配
{ field: value }

// 示例：查找优先级为 1 的待办
db.useQuery({
  todos: {
    $: { where: { priority: 1 } }
  }
})
```

#### 不等值查询

```typescript
// 不等于
{ field: { $ne: value } }

// 示例：查找未完成的待办
db.useQuery({
  todos: {
    $: { where: { status: { $ne: 'completed' } } }
  }
})
```

#### 空值检查

```typescript
// 为空
{ field: { $isNull: true } }

// 不为空
{ field: { $isNull: false } }

// 示例：查找没有截止日期的待办
db.useQuery({
  todos: {
    $: { where: { dueDate: { $isNull: true } } }
  }
})
```

#### 比较操作符（需要 indexed）

```typescript
// 大于、小于、大于等于、小于等于
{ field: { $gt: value } }  // 大于
{ field: { $lt: value } }  // 小于
{ field: { $gte: value } } // 大于等于
{ field: { $lte: value } } // 小于等于

// 示例：查找今天创建的待办
const todayStart = new Date();
todayStart.setHours(0, 0, 0, 0);

db.useQuery({
  todos: {
    $: {
      where: {
        createdAt: { $gte: todayStart.getTime() }
      }
    }
  }
})
```

#### 集合操作

```typescript
// 在列表中
{ field: { $in: [value1, value2] } }

// 示例：查找高优先级或紧急任务
db.useQuery({
  todos: {
    $: { where: { priority: { $in: [1, 2] } } }
  }
})
```

#### 字符串匹配

```typescript
// 区分大小写
{ field: { $like: 'Get%' } }      // 以 'Get' 开头
{ field: { $like: '%done' } }     // 以 'done' 结尾
{ field: { $like: '%work%' } }    // 包含 'work'

// 不区分大小写
{ field: { $ilike: '%get%' } }   // 包含 'get' 或 'GET' 或 'Get'

// 示例：搜索标题包含 'buy' 的待办
db.useQuery({
  todos: {
    $: { where: { title: { $ilike: '%buy%' } } }
  }
})
```

#### 逻辑操作符

```typescript
// AND 操作
and: [
  { condition1 },
  { condition2 }
]

// OR 操作
or: [
  { condition1 },
  { condition2 }
]

// 示例：查找高优先级且未完成的待办
db.useQuery({
  todos: {
    $: {
      where: {
        and: [
          { priority: { $gte: 3 } },
          { status: { $ne: 'completed' } }
        ]
      }
    }
  }
})
```

#### 嵌套字段查询

```typescript
// 查询关联实体的字段
'relation.field': value

// 示例：查找特定作者的待办
db.useQuery({
  todos: {
    $: { where: { 'author.name': 'John' } }
  }
})
```

### A.5 完整示例：Reddit Clone

System Prompt 提供了一个完整的 Reddit Clone 示例（958 行代码），展示了：

1. **Schema 设计**：posts、comments、votes 三个实体
2. **关系定义**：postComments、votePost、voteComment 链接
3. **CRUD 操作**：创建、更新、删除、投票
4. **实时查询**：`db.useQuery` 自动更新
5. **UI 组件**：卡片、表单、模态框
6. **样式系统**：React Native StyleSheet

**关键学习点**：

```typescript
// 1. Schema 设计
const schema = i.schema({
  entities: {
    posts: i.entity({
      title: i.string(),
      body: i.string(),
      authorId: i.string(),
      timestamp: i.number().indexed(),  // ✅ indexed 用于排序
    }),
    // ...
  },
  links: {
    postComments: {
      forward: { on: 'comments', has: 'one', label: 'post' },
      reverse: { on: 'posts', has: 'many', label: 'comments' },
    },
  },
});

// 2. 初始化
const db = init({ appId: APP_ID, schema });

// 3. 创建数据
db.transact(
  db.tx.posts[id()].create({
    title,
    body,
    authorId,
    timestamp: Date.now()
  })
);

// 4. 实时查询
const { data } = db.useQuery({
  posts: {
    $: { order: { timestamp: 'desc' } },  // ✅ 按 timestamp 排序
    comments: {
      votes: {}  // 嵌套查询
    }
  }
});
```

### A.6 格式化规则

```markdown
CRITICAL FORMATTING RULES:

1. Do NOT use markdown code fences anywhere
2. The response should contain ONLY raw JavaScript/React code
3. Start directly with the import statements
4. No explanations or text outside the code
```

这些规则确保 AI 返回的代码能直接被 `codeStrToReactElement` 处理。

**示例对比**：

❌ **错误格式**（带 markdown）：
````markdown
Here's the code you requested:

```typescript
import React from 'react';
// ...
```

Hope this helps!
````

✅ **正确格式**（纯代码）：
```typescript
import React from 'react';
import { View, Text } from 'react-native';
// ...
export default App = () => {
  return <View><Text>Hello</Text></View>;
};
```

### A.7 System Prompt 的完整流程

```mermaid
sequenceDiagram
    participant User as 用户
    participant App as App Builder
    participant AI as AI (GPT-5)
    participant Prompt as System Prompt
    participant Executor as codeStrToReactElement

    User->>App: 输入需求 "做个待办应用"
    App->>AI: 发送请求 + System Prompt
    AI->>Prompt: 读取规则
    Prompt-->>AI: 返回约束和最佳实践
    AI->>AI: 生成符合规范的代码
    AI-->>App: 返回纯代码字符串
    App->>Executor: 执行代码
    Executor-->>App: 返回 React 元素
    App-->>User: 显示可运行的界面

    Note over AI,Prompt: System Prompt 是关键<br/>它确保 AI 生成的代码<br/>能在动态环境中运行
```

### A.8 总结：System Prompt 的价值

```mermaid
mindmap
  root((System Prompt))
    技术约束
      React Native
      StyleSheet
      InstantDB
    代码质量
      Hooks 规则
      单文件 < 500 行
      简洁可维护
    InstantDB 规范
      使用 UUID
      索引字段
      查询操作符
    格式要求
      无 markdown
      纯代码
      直接可执行
```

**System Prompt 的核心价值**：

1. ✅ **保证代码可运行**：生成的代码符合动态执行环境的要求
2. ✅ **提升代码质量**：强制遵循 React 最佳实践
3. ✅ **正确使用 InstantDB**：避免常见的数据库操作错误
4. ✅ **统一代码风格**：所有 AI 生成的应用风格一致
5. ✅ **简化后处理**：纯代码格式，无需额外的解析步骤

这个精心设计的 System Prompt 是整个项目成功的关键因素之一！

---

## 总结

我们学习了如何让 AI 生成的代码"活"过来：

1. **Babel 转译**：把 JSX/TypeScript 变成纯 JavaScript
2. **模拟模块**：提供一个假的 `require` 函数，只允许访问白名单模块
3. **动态执行**：用 `new Function` 在沙箱里执行代码
4. **返回组件**：得到一个真正的 React 组件，可以渲染

```mermaid
mindmap
  root((动态代码执行))
    准备阶段
      Babel 转译
      移除 JSX/TS
      ES6 → CommonJS
    执行阶段
      创建沙箱
      自定义 require
      new Function
    输出阶段
      获取组件
      createElement
      渲染到屏幕
```

这个技术的核心思想是：
- ✅ **灵活性**：无需重新编译应用
- ✅ **安全性**：白名单限制模块访问
- ✅ **实时性**：立即看到 AI 生成的代码运行

虽然有一些局限性和安全风险，但对于演示和原型开发，这是一个非常优雅的解决方案！
