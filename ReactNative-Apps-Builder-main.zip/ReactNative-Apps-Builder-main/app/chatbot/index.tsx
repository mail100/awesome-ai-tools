import { Colors } from '@/constants/Colors';
import codeStrToReactElementSimple from '@/utils/codeStrToReactElementSimple';
import { useState } from 'react';
import {
  ActivityIndicator,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

// 数据结构
interface GeneratedComponent {
  id: string;
  prompt: string;
  code: string;
  element: React.ReactElement | null;
  generationTime: number; // AI 生成时间
  babelTime: number; // Babel 转译时间
  executionTime: number; // 代码执行时间
  totalTime: number; // 总时间
  error: string | null;
  timestamp: number;
}

export default function Chatbot() {
  const [prompt, setPrompt] = useState('');
  const [components, setComponents] = useState<GeneratedComponent[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    const currentPrompt = prompt;
    setPrompt('');
    setIsGenerating(true);

    try {
      const response = await fetch('/api/generate-simple', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: currentPrompt }),
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const { code, generationTime } = await response.json();

      // 执行代码并测量详细时间
      let element: React.ReactElement | null = null;
      let error: string | null = null;
      let babelTime = 0;
      let executionTime = 0;

      try {
        const babelStart = performance.now();
        element = codeStrToReactElementSimple(code);
        const babelEnd = performance.now();

        babelTime = babelEnd - babelStart;
        executionTime = 0; // 已经包含在 babel 转译中
      } catch (e: any) {
        error = e.message || 'Failed to execute generated code';
        console.error('Execution error:', e);
      }

      const totalTime = generationTime + babelTime + executionTime;

      // 创建最终组件
      const newComponent: GeneratedComponent = {
        id: Date.now().toString(),
        prompt: currentPrompt,
        code,
        element,
        generationTime,
        babelTime,
        executionTime,
        totalTime,
        error,
        timestamp: Date.now(),
      };

      setComponents(prev => [newComponent, ...prev]);
    } catch (error: any) {
      console.error('Generation error:', error);

      const errorComponent: GeneratedComponent = {
        id: Date.now().toString(),
        prompt: currentPrompt,
        code: '',
        element: null,
        generationTime: 0,
        babelTime: 0,
        executionTime: 0,
        totalTime: 0,
        error: error.message || 'Failed to generate component',
        timestamp: Date.now(),
      };

      setComponents(prev => [errorComponent, ...prev]);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDelete = (id: string) => {
    setComponents(prev => prev.filter(c => c.id !== id));
  };

  const handleClearAll = () => {
    setComponents([]);
  };

  return (
    <View style={styles.container}>
      {/* 输入区域 */}
      <View style={styles.inputSection}>
        <TextInput
          style={styles.input}
          multiline
          numberOfLines={4}
          textAlignVertical="top"
          placeholder="Describe a component you want to build..."
          value={prompt}
          onChangeText={setPrompt}
          editable={!isGenerating}
        />
        <View style={styles.buttonRow}>
          <TouchableOpacity
            style={[styles.button, styles.generateButton]}
            onPress={handleGenerate}
            disabled={isGenerating || !prompt.trim()}
          >
            <Text style={styles.buttonText}>
              {isGenerating ? 'Generating...' : 'Generate'}
            </Text>
          </TouchableOpacity>

          {components.length > 0 && (
            <TouchableOpacity
              style={[styles.button, styles.clearButton]}
              onPress={handleClearAll}
              disabled={isGenerating}
            >
              <Text style={styles.buttonText}>Clear All</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* 组件列表 */}
      <ScrollView style={styles.componentsList}>
        {components.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>
              No components generated yet. Start by describing a component above!
            </Text>
          </View>
        ) : (
          components.map((component) => (
            <ComponentCard
              key={component.id}
              component={component}
              onDelete={handleDelete}
            />
          ))
        )}
      </ScrollView>

      {/* 加载遮罩 */}
      {isGenerating && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="large" color="#fff" />
          <Text style={styles.loadingText}>Generating your component...</Text>
          <Text style={styles.loadingSubtext}>This may take a few seconds</Text>
        </View>
      )}
    </View>
  );
}

// 组件卡片子组件
function ComponentCard({
  component,
  onDelete,
}: {
  component: GeneratedComponent;
  onDelete: (id: string) => void;
}) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [showCode, setShowCode] = useState(false);

  return (
    <View style={styles.card}>
      {/* 卡片头部 */}
      <View style={styles.cardHeader}>
        <View style={styles.cardHeaderLeft}>
          <Text style={styles.promptText} numberOfLines={2}>
            {component.prompt}
          </Text>
          <View style={styles.metrics}>
            <Text style={styles.metricText}>
              ⚡ {component.totalTime.toFixed(0)}ms total
            </Text>
          </View>
        </View>
        <View style={styles.cardHeaderRight}>
          <TouchableOpacity onPress={() => setIsExpanded(!isExpanded)}>
            <Text style={styles.toggleText}>
              {isExpanded ? '▼' : '▶'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => onDelete(component.id)}>
            <Text style={styles.deleteText}>✕</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* 组件内容 */}
      {isExpanded && (
        <View style={styles.cardContent}>
          {component.error ? (
            <View style={styles.errorBox}>
              <Text style={styles.errorText}>❌ {component.error}</Text>
            </View>
          ) : (
            <>
              {/* 性能指标详情 */}
              <View style={styles.performanceDetails}>
                <Text style={styles.performanceTitle}>Performance Breakdown:</Text>
                <View style={styles.performanceRow}>
                  <Text style={styles.performanceLabel}>AI Generation:</Text>
                  <Text style={styles.performanceValue}>{component.generationTime.toFixed(0)}ms</Text>
                </View>
                <View style={styles.performanceRow}>
                  <Text style={styles.performanceLabel}>Babel Transpilation:</Text>
                  <Text style={styles.performanceValue}>{component.babelTime.toFixed(0)}ms</Text>
                </View>
                <View style={styles.performanceRow}>
                  <Text style={styles.performanceLabel}>Execution:</Text>
                  <Text style={styles.performanceValue}>{component.executionTime.toFixed(0)}ms</Text>
                </View>
                <View style={[styles.performanceRow, styles.performanceTotal]}>
                  <Text style={styles.performanceLabelTotal}>Total:</Text>
                  <Text style={styles.performanceValueTotal}>{component.totalTime.toFixed(0)}ms</Text>
                </View>
              </View>

              {/* 查看代码按钮 */}
              <TouchableOpacity
                style={styles.showCodeButton}
                onPress={() => setShowCode(!showCode)}
              >
                <Text style={styles.showCodeButtonText}>
                  {showCode ? '📦 Hide Code' : '📄 View Code'}
                </Text>
              </TouchableOpacity>

              {/* 代码预览 */}
              {showCode && (
                <View style={styles.codePreviewContainer}>
                  <View style={styles.codePreviewHeader}>
                    <Text style={styles.codePreviewTitle}>Generated Code</Text>
                  </View>
                  <ScrollView style={styles.codePreviewContent}>
                    <Text style={styles.codePreviewText}>
                      {component.code}
                    </Text>
                  </ScrollView>
                </View>
              )}

              {/* 渲染的组件 */}
              <View style={styles.componentPreview}>
                {component.element || <Text style={styles.loadingText}>Loading...</Text>}
              </View>
            </>
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  loadingText: {
    color: '#fff',
    marginTop: 16,
    fontSize: 18,
    fontWeight: '600',
  },
  loadingSubtext: {
    color: '#ccc',
    marginTop: 8,
    fontSize: 14,
  },
  inputSection: {
    backgroundColor: '#fff',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
    backgroundColor: '#fafafa',
    minHeight: 100,
    fontSize: 16,
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 8,
  },
  button: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  generateButton: {
    backgroundColor: Colors.primary,
  },
  clearButton: {
    backgroundColor: '#666',
    flex: 0.4,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  componentsList: {
    flex: 1,
    padding: 16,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    color: '#999',
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#e0e0e0',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: 12,
    backgroundColor: '#f9f9f9',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  cardHeaderLeft: {
    flex: 1,
    marginRight: 8,
  },
  promptText: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
    color: '#333',
  },
  metrics: {
    marginTop: 4,
  },
  metricText: {
    fontSize: 12,
    color: '#666',
  },
  cardHeaderRight: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'center',
  },
  toggleText: {
    fontSize: 16,
    color: '#666',
  },
  deleteText: {
    fontSize: 18,
    color: '#f44336',
    fontWeight: 'bold',
  },
  cardContent: {
    padding: 12,
  },
  errorBox: {
    backgroundColor: '#ffebee',
    padding: 12,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#f44336',
  },
  errorText: {
    color: '#c62828',
    fontSize: 14,
  },
  loadingText: {
    color: '#999',
    textAlign: 'center',
    padding: 20,
  },
  performanceDetails: {
    backgroundColor: '#f0f7ff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#2196F3',
  },
  performanceTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: '#1976D2',
    marginBottom: 8,
  },
  performanceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  performanceLabel: {
    fontSize: 12,
    color: '#555',
  },
  performanceValue: {
    fontSize: 12,
    fontWeight: '600',
    color: '#333',
  },
  performanceTotal: {
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#bbdefb',
  },
  performanceLabelTotal: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#1976D2',
  },
  performanceValueTotal: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#1976D2',
  },
  showCodeButton: {
    backgroundColor: '#4CAF50',
    padding: 10,
    borderRadius: 6,
    alignItems: 'center',
    marginBottom: 12,
  },
  showCodeButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  codePreviewContainer: {
    backgroundColor: '#263238',
    borderRadius: 8,
    overflow: 'hidden',
    marginBottom: 12,
  },
  codePreviewHeader: {
    backgroundColor: '#37474F',
    padding: 8,
  },
  codePreviewTitle: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  codePreviewContent: {
    maxHeight: 200,
    padding: 12,
  },
  codePreviewText: {
    color: '#aed581',
    fontSize: 12,
    fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
    lineHeight: 18,
  },
  componentPreview: {
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    padding: 8,
    backgroundColor: '#fafafa',
    minHeight: 100,
  },
});
