import { getSimpleSystemPrompt } from "@/utils/systemPrompt";
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { streamText } from "ai";

export async function POST(req: Request) {
  const { prompt } = await req.json();

  try {
    const startTime = performance.now();
    let code = "";

    const glm = createOpenAICompatible({
      name: "glm",
      apiKey: process.env.GLM_API_KEY,
      baseURL: "https://open.bigmodel.cn/api/coding/paas/v4",
    });

    const { fullStream } = streamText({
      model: glm("glm-4.7"),
      prompt: prompt,
      system: getSimpleSystemPrompt(),
      providerOptions: {
        glm: {
          enable_thinking: false,
        },
      },
    });

    // 收集所有代码（后台流式处理）
    for await (const chunk of fullStream) {
      if (chunk.type === "text-delta") {
        code += chunk.text;
      }
    }

    const generationTime = performance.now() - startTime;

    return Response.json({
      code,
      generationTime,
    });
  } catch (error: any) {
    console.error("Error in generate-simple API:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}
