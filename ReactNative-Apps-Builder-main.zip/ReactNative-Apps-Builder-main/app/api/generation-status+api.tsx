import { getGenerationState } from "@/lib/generationStore";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");

  if (!id) {
    return Response.json({ error: "Missing id parameter" }, { status: 400 });
  }

  const state = getGenerationState(id);

  if (!state) {
    return Response.json({ error: "Generation not found" }, { status: 404 });
  }

  return Response.json(state);
}
