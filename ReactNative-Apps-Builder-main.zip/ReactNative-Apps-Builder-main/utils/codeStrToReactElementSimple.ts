import * as Babel from '@babel/standalone';
import React from 'react';
import ReactNative from 'react-native';

export default function codeStrToReactElementSimple(inputCode: string) {
  let code = inputCode;

  // 清理代码：查找第一个 import 语句并从那里开始
  const importIndex = code.indexOf('import ');
  if (importIndex > 0) {
    code = code.substring(importIndex);
  }

  // 去除 "export default App;" 之后的文本
  const exportText = 'export default App;';
  const exportIndex = code.indexOf(exportText);
  if (exportIndex > -1) {
    code = code.substring(0, exportIndex + exportText.length);
  }

  // 使用 Babel 转换代码
  const transformed = Babel.transform(code.trim(), {
    presets: [['env', { targets: { esmodules: true } }], 'react', 'typescript'],
    filename: 'component.tsx',
    plugins: [['transform-modules-commonjs', { strict: false }]],
  }).code;

  // 创建模块函数
  const moduleCode = `
    const exports = {};
    const module = { exports };

    const require = (name) => {
      if (name === 'react') return React;
      if (name === 'react-native') return ReactNative;
      throw new Error('Module not found: ' + name);
    };

    ${transformed}

    return module.exports.default || module.exports;
  `;

  const moduleFn = new Function('React', 'ReactNative', moduleCode);
  const Component = moduleFn(React, ReactNative);

  return React.createElement(Component);
}
