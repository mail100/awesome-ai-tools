import fs from 'fs';
import path from 'path';

const promptPath = path.join(process.cwd(), 'resources/systemPrompt.txt');
const simplePromptPath = path.join(process.cwd(), 'resources/systemPrompt-simple.txt');

export function getSystemPrompt() {
  return fs.readFileSync(promptPath, 'utf-8');
}

export function getSimpleSystemPrompt() {
  return fs.readFileSync(simplePromptPath, 'utf-8');
}
